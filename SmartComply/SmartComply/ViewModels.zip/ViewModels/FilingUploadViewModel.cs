﻿namespace SmartComply.ViewModels
{
    using Microsoft.AspNetCore.Http;
    using System.ComponentModel.DataAnnotations;
    public class FilingUploadViewModel
    {
        public string FilingTitle { get; set; }  // Already used for title/compliance
        public string Tags { get; set; }
        public IFormFile File { get; set; }
    }

}
